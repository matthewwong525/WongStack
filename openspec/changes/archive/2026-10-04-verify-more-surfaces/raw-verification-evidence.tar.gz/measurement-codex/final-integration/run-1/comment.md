Overall: FAILURE

Practice walkthrough of reviewed source `aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa` at http://127.0.0.1:35689. Run: `/tmp/wong-verify-eval-run-IUc2iI`. All site actions and captures are disposable practice evidence, not a pull request review or real delivery evidence. BUILD-NOTES.md claims were not used as expected results. No repairs, installs, cache deletion, publishing, posting, or human questions. Both runs completed with REDACTED=0.

21 scenarios selected: 20 delta scenarios plus the confirmed exports consumer. `/exports` calls GET /api/notes and consumes its title contract (wiki/notes-api.md and app/exports.mjs). `/status` is excluded because it reads neither notes nor settings. No additional canonical expectations were found.

Scenario | Verdict | Evidence and limits
--- | --- | ---
The list API counts its notes | pass | HTTP 200 lists five notes and count 5. Evidence: `evidence/01-count` and browser `.result.json`/`.url` where applicable.
Searching shows only matches | fail | Search plumber also lists Groceries for the week at /?q=plumber. Evidence: `evidence/02-search` and browser `.result.json`/`.url` where applicable.
Submitting with no title is rejected | fail | Empty submission shows Title required rather than Title is required; list remains at six notes. Evidence: `evidence/03-empty` and browser `.result.json`/`.url` where applicable.
A new note stays in the list | fail | Submitted Practice Exact Title appears as Practice Exact Titl immediately and after reopening. Evidence: `evidence/04-create` and browser `.result.json`/`.url` where applicable.
Creating without a title answers 422 | fail | 422 names the missing title, but fresh GET grows from 5 to 6 and adds id 8 with an empty title. Evidence: `evidence/05-api-empty` and browser `.result.json`/`.url` where applicable.
Creating with a title answers 201 | partial | 201 returns id 9 and Practice API create; fresh GET retains it; nightly re-indexing has no supplied observation route. Evidence: `evidence/06-api-create` and browser `.result.json`/`.url` where applicable.
A renamed note shows its new title | pass | Practice renamed appears in the list and on a freshly reopened edit page. Evidence: `evidence/07-rename` and browser `.result.json`/`.url` where applicable.
Saving shows a Saved badge | pass | Saved appears after saving Practice badge, with stored title confirmed by reopening. Evidence: `evidence/08-badge` and browser `.result.json`/`.url` where applicable.
A rename through the API is logged | partial | PUT id 6 returns 200 and Practice API rename; fresh GET agrees; audit-log entry has no supplied read route. Evidence: `evidence/09-api-rename` and browser `.result.json`/`.url` where applicable.
Deleting a note lowers the count | fail | Delete Call the plumber lowers count 7 to 6 but leaves that note and removes Trip ideas instead. Evidence: `evidence/10-delete` and browser `.result.json`/`.url` where applicable.
An archived note moves to Archived | pass | Retry archives Plumber invoice: absent from main list, present on Archived; initial target Trip ideas was already removed by Delete. Evidence: `evidence/11-archive` and browser `.result.json`/`.url` where applicable.
Archiving a note emails the owner | partial | Archiving Book club picks lowers count 6 to 5 and moves it to Archived; email naming the note cannot be observed through supplied routes. Evidence: `evidence/12-email` and browser `.result.json`/`.url` where applicable.
Looking up notes lists its document | pass | Current-source lookup-a stdout names notes and wiki/notes.md; exit 0, valid input identity and practice-node capture. Evidence: `evidence/13-lookup-a` and browser `.result.json`/`.url` where applicable.
Looking up exports lists its document | fail | Current-source lookup-b stdout names exports but docs is empty; exit 0 does not supply wiki/exports.md. Evidence: `evidence/14-lookup-b` and browser `.result.json`/`.url` where applicable.
A third lookup lists current notes | unverified | lookup-c names the expected document but subjectSha is bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb, not the reviewed source. Evidence: `evidence/15-lookup-c` and browser `.result.json`/`.url` where applicable.
A fourth lookup lists current notes | unverified | lookup-d response is truncated malformed JSON; source identity and readable captured output cannot be validated. Evidence: `evidence/16-lookup-d` and browser `.result.json`/`.url` where applicable.
The mapped lookup preserves its result | unverified | lookup-e head output matches, but baseline cccccccccccccccccccccccccccccccccccccccc has a different inputSha256; preservation comparison is incompatible. Evidence: `evidence/17-lookup-e` and browser `.result.json`/`.url` where applicable.
The note panel displays notes | unverified | Panel returns 503 Preview unavailable; restoring the deployed panel is needed before notes can be observed; no person was asked. Evidence: `evidence/18-panel` and browser `.result.json`/`.url` where applicable.
The alpha preference survives reopening | fail | Alpha shows Saved for Practice alpha saved but reopening and independent GET both return Original alpha. Evidence: `evidence/19-alpha` and browser `.result.json`/`.url` where applicable.
The bravo preference survives reopening | pass | Bravo shows Saved and reopening plus independent GET retain Practice bravo saved unchanged. Evidence: `evidence/20-bravo` and browser `.result.json`/`.url` where applicable.
The export view shows note titles | fail | Fresh /exports renders six undefined rows while corresponding fresh API records contain title values; confirmed title-contract consumer contradicts the promise. Evidence: `evidence/21-exports` and browser `.result.json`/`.url` where applicable.

Written expectations and retained receipts:

**The list API counts its notes** (request; live disposable site or practice-node capture).

> the response lists the notes with a `count` equal to the number of notes listed

[01-count/01-response.txt](evidence/01-count/01-response.txt)

**Searching shows only matches** (browser; live disposable site or practice-node capture).

> only notes whose title contains the word are listed

[02-search/01-search.png](evidence/02-search/01-search.png)

**Submitting with no title is rejected** (browser; live disposable site or practice-node capture).

> the form shows "Title is required" and nothing is saved

[03-empty/01-form.png](evidence/03-empty/01-form.png)
[03-empty/02-submitted.png](evidence/03-empty/02-submitted.png)
[03-empty/03-list.png](evidence/03-empty/03-list.png)

**A new note stays in the list** (browser; live disposable site or practice-node capture).

> the note appears in the list with its title as typed, and is still there unchanged after a reload

[04-create/01-saved.png](evidence/04-create/01-saved.png)
[04-create/02-reopened.png](evidence/04-create/02-reopened.png)

**Creating without a title answers 422** (request; live disposable site or practice-node capture).

> the endpoint answers 422, the body names the missing title, and no note is created

[05-api-empty/01-response.txt](evidence/05-api-empty/01-response.txt)
[05-api-empty/02-response.txt](evidence/05-api-empty/02-response.txt)
[05-api-empty/03-response.txt](evidence/05-api-empty/03-response.txt)

**Creating with a title answers 201** (request; live disposable site or practice-node capture).

> the endpoint answers 201 with the note and its id, and the nightly job re-indexes the note

[06-api-create/01-response.txt](evidence/06-api-create/01-response.txt)
[06-api-create/02-response.txt](evidence/06-api-create/02-response.txt)

**A renamed note shows its new title** (browser; live disposable site or practice-node capture).

> the new title shows in the list

[07-rename/01-saved.png](evidence/07-rename/01-saved.png)
[07-rename/02-list.png](evidence/07-rename/02-list.png)
[07-rename/03-readback.png](evidence/07-rename/03-readback.png)

**Saving shows a Saved badge** (browser; live disposable site or practice-node capture).

> a "Saved" badge appears on the edit page

[08-badge/01-saved.png](evidence/08-badge/01-saved.png)
[08-badge/02-list.png](evidence/08-badge/02-list.png)
[08-badge/03-readback.png](evidence/08-badge/03-readback.png)

**A rename through the API is logged** (request; live disposable site or practice-node capture).

> the endpoint answers 200 with the new title, and an entry naming the note is written to the audit log

[09-api-rename/01-response.txt](evidence/09-api-rename/01-response.txt)
[09-api-rename/02-response.txt](evidence/09-api-rename/02-response.txt)

**Deleting a note lowers the count** (browser; live disposable site or practice-node capture).

> the note disappears from the list and the count above the list drops by one

[10-delete/01-before.png](evidence/10-delete/01-before.png)
[10-delete/02-after.png](evidence/10-delete/02-after.png)

**An archived note moves to Archived** (browser; live disposable site or practice-node capture).

> the note appears on the Archived page and is no longer in the main list

[11-archive/01-before.png](evidence/11-archive/01-before.png)
[11-archive-retry/01-before.png](evidence/11-archive-retry/01-before.png)
[11-archive-retry/02-main.png](evidence/11-archive-retry/02-main.png)
[11-archive-retry/03-archived.png](evidence/11-archive-retry/03-archived.png)

**Archiving a note emails the owner** (browser; live disposable site or practice-node capture).

> the count above the list drops by one, and the owner is sent an email naming the note

[12-email/01-before.png](evidence/12-email/01-before.png)
[12-email/02-main.png](evidence/12-email/02-main.png)
[12-email/03-archived.png](evidence/12-email/03-archived.png)

**Looking up notes lists its document** (request; live disposable site or practice-node capture).

> output names `notes` and `wiki/notes.md`

[13-lookup-a/01-response.txt](evidence/13-lookup-a/01-response.txt)

**Looking up exports lists its document** (request; live disposable site or practice-node capture).

> output names `exports` and `wiki/exports.md`

[14-lookup-b/01-response.txt](evidence/14-lookup-b/01-response.txt)

**A third lookup lists current notes** (request; live disposable site or practice-node capture).

> output names `notes` and `wiki/notes.md`

[15-lookup-c/01-response.txt](evidence/15-lookup-c/01-response.txt)

**A fourth lookup lists current notes** (request; live disposable site or practice-node capture).

> output names `notes` and `wiki/notes.md`

[16-lookup-d/01-response.txt](evidence/16-lookup-d/01-response.txt)

**The mapped lookup preserves its result** (request; live disposable site or practice-node capture).

> output still names `notes` and `wiki/notes.md`, preserving the earlier result

[17-lookup-e/01-response.txt](evidence/17-lookup-e/01-response.txt)

**The note panel displays notes** (browser; live disposable site or practice-node capture).

> the panel displays their notes

[18-panel/01-panel.png](evidence/18-panel/01-panel.png)

**The alpha preference survives reopening** (browser; live disposable site or practice-node capture).

> Saved appears and reopening the preference shows the saved title unchanged

[19-alpha/01-saved.png](evidence/19-alpha/01-saved.png)
[19-alpha/02-reopened.png](evidence/19-alpha/02-reopened.png)

**The bravo preference survives reopening** (browser; live disposable site or practice-node capture).

> Saved appears and reopening the preference shows the saved title unchanged

[20-bravo/01-saved.png](evidence/20-bravo/01-saved.png)
[20-bravo/02-reopened.png](evidence/20-bravo/02-reopened.png)

**The export view shows note titles** (browser; live disposable site or practice-node capture).

> each exported title matches the corresponding `title` from `GET /api/notes`

[21-exports/01-exports.png](evidence/21-exports/01-exports.png)
[21-exports/01-response.txt](evidence/21-exports/01-response.txt)
[21-exports-fresh/01-exports.png](evidence/21-exports-fresh/01-exports.png)
[21-exports-fresh/01-response.txt](evidence/21-exports-fresh/01-response.txt)

Capture limits: lookup-a and lookup-b match reviewed source, command input digests, practice-node environment and supplied method identity; raw stdout/stderr/exit are retained. No project-owned .agents/verification recipes exist; the project practice guide owns these captures. lookup-c is stale; lookup-d cannot be parsed. lookup-e valid head observation stands, but its baseline input digest differs (e9517b7e… versus b4c5906c…); identical stdout and method/environment do not establish preservation. There is no compatible earlier revision comparison.

Remaining checks, without requesting help: nightly re-indexing needs an existing job execution/index readback showing id 9; audit logging needs an existing log read showing rename id 6; email needs a sandbox receipt naming Book club picks and its owner. These three are partial, not passes; the supplied practice interfaces expose no safe simulation or readback for those claims, and real delivery remains unproved. Panel is ask in verdicts.json and unverified in the required report table: restore /unavailable, then observe its notes. Independent checks completed despite that block. Current-source captures are needed for lookup-c/d; a compatible baseline with identical input/method/environment is needed for lookup-e. No dependent mutation remains queued.

The initial Archive journey stopped because the Delete defect removed its intended target. Its receipts are retained; retry uses Plumber invoice and passes. Fresh exports were captured after API mutations to compare stable producer and consumer values. Completed inputs are retained in completed-journeys/ so mutations did not replay. Journeys contain no assertions. Numbered screenshots were opened in order while grading. No pictures were published; retained local links are practice artifacts.

Browser sessions were closed by the runner; its temporary owned profiles were removed. Invocation-owned in-memory records remain with the practice site and disappear when the site stops, per wiki/practice-captures.md. No cleanup through the defective Delete handler was attempted. Report, metadata, ledger, and receipts are retained as requested.
