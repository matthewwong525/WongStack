# Final integration evidence

The current saved walkthrough at `9f87a05ca1d87f9af1d9a2255b3dd4b515acbd41`, including the practical-repair paragraph, was exercised once with the existing mixed practice harness. Practice source `aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa` is the harness identity, not a GitHub revision. This smoke run is separate from the frozen before/after measurement; its inputs/scorer were not changed after results.

`results.json` retains the frozen score, including its Markdown-table parser limitation. `run-1/run-folder/comment.md` has the full human-inspected report and working relative evidence links. Actual readbacks and selected producer/consumer checks are in `run-1/observations.json`; the native trace reports 64,775 tokens. Elapsed time is 4.745 minutes; dollar cost was unavailable. No performance-gain claim follows from this one run.

`ci-comparison.json` is the validated actual GitHub memory capture at saved head 9f87a05, run 37184710803 attempt 1, selected merge-base 932439bf1109066faaf2aec85cf653db3941ff4b. `ci-preflight-regression/` retains the independent actual Git-source same-check failure before ab27e29989bbf4074b8949210d1c7cae2f64ae25 and pass after 9f87a05. Its disposable browser/preview fixture is mocked and is not a live-preview observation. See ../../evidence.md for the final coverage and limits.
